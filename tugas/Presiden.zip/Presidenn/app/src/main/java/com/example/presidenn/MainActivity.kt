package com.example.presidenn

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var listView : ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.listView)
        var list = mutableListOf<Model>()

        list.add(Model("Soekarno",   "Presiden RI yang pertama",   R.drawable.soekarno  ))
        list.add(Model("Soeharto",   "Presiden RI yang pertama",   R.drawable.soeharto  ))
        list.add(Model("Habibi", "Presiden RI yang ketiga", R.drawable.habibi  ))
        list.add(Model("Gus Dur",  "Presiden RI yang keempat",  R.drawable.gusdur  ))
        list.add(Model("Megawati",  "Presiden RI yang kelima",  R.drawable.megawati  ))
        list.add(Model("Susilo Bambang Yudhoyono",  "Presiden RI yang keenam", R.drawable.sby  ))
        list.add(Model("Joko widodo",  "Presiden RI yang ketujuh",  R.drawable.jokowi  ))

        listView.adapter = MyListAdapter(this,R.layout.row,list)

        listView.setOnItemClickListener{parent, view, position, id ->

            if (position==0){
                Toast.makeText(this@MainActivity, "Presiden RI yang pertama",   Toast.LENGTH_SHORT).show()
            }
            if (position==1){
                Toast.makeText(this@MainActivity, "Presiden RI yang pertama",   Toast.LENGTH_SHORT).show()
            }
            if (position==2){
                Toast.makeText(this@MainActivity, "Presiden RI yang ketiga", Toast.LENGTH_SHORT).show()
            }
            if (position==3){
                Toast.makeText(this@MainActivity, "Presiden RI yang keempat",  Toast.LENGTH_SHORT).show()
            }
            if (position==4){
                Toast.makeText(this@MainActivity, "Presiden RI yang kelima",  Toast.LENGTH_SHORT).show()
            }
            if (position==5){
                Toast.makeText(this@MainActivity, "Presiden RI yang keenam",  Toast.LENGTH_SHORT).show()
            }
            if (position==6){
                Toast.makeText(this@MainActivity, "Presiden RI yang ketujuh",  Toast.LENGTH_SHORT).show()
            }

}
    }
}