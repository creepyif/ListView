package com.example.listviewicon.model

class Prog {
    var name:String=""
    var detail: String=""
    var poster : Int = 0

}