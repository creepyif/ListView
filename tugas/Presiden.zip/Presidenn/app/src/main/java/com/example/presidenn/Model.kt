package com.example.presidenn

class Model(val title:String, val desc:String, val photo:Int )
